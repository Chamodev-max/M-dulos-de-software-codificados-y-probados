// ===== SEGURIDAD =====
document.addEventListener("DOMContentLoaded", () => {
    const ruta = window.location.pathname;

    if (ruta.includes("dashboard.html")) {
        if (!localStorage.getItem("usuarioActivo")) {
            window.location.href = "login.html";
        }
    }
});

// ===== STORAGE =====
const Storage = {
    get(key) {
        return JSON.parse(localStorage.getItem(key)) || [];
    },
    set(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }
};

// ===== MODELOS =====
class Usuario {
    constructor(correo, password) {
        this.correo = correo;
        this.password = password;
    }
}

class Cita {
    constructor(mascota, servicio, fecha, usuario) {
        this.id = Date.now();
        this.mascota = mascota;
        this.servicio = servicio;
        this.fecha = fecha;
        this.usuario = usuario;
    }
}

// ===== AUTH =====
const Auth = {
    registrar(correo, password) {
        let usuarios = Storage.get("usuarios");

        if (usuarios.find(u => u.correo === correo)) {
            alert("El usuario ya existe");
            return;
        }

        usuarios.push(new Usuario(correo, password));
        Storage.set("usuarios", usuarios);

        alert("Registro exitoso");
        window.location.href = "login.html";
    },

    login(correo, password) {
        let usuarios = Storage.get("usuarios");

        let user = usuarios.find(u => u.correo === correo && u.password === password);

        if (!user) {
            alert("Credenciales incorrectas");
            return;
        }

        localStorage.setItem("usuarioActivo", correo);
        window.location.href = "dashboard.html";
    },

    logout() {
        localStorage.removeItem("usuarioActivo");
        window.location.href = "login.html";
    },

    getUsuarioActivo() {
        return localStorage.getItem("usuarioActivo");
    }
};

// ===== CITAS =====
const CitasService = {
    crear(mascota, servicio, fecha) {
        let usuario = Auth.getUsuarioActivo();

        if (!usuario) {
            alert("Debes iniciar sesión primero");
            return;
        }

        let citas = Storage.get("citas");

        citas.push(new Cita(mascota, servicio, fecha, usuario));

        Storage.set("citas", citas);
        UI.renderCitas();
    },

    obtenerPorUsuario() {
        let usuario = Auth.getUsuarioActivo();
        return Storage.get("citas").filter(c => c.usuario === usuario);
    },

    eliminar(id) {
        let citas = Storage.get("citas").filter(c => c.id !== id);
        Storage.set("citas", citas);
        UI.renderCitas();
    }
};

// ===== UI =====
const UI = {
    renderCitas() {
        let contenedor = document.getElementById("listaCitas");
        if (!contenedor) return;

        let citas = CitasService.obtenerPorUsuario();
        contenedor.innerHTML = "";

        if (citas.length === 0) {
            contenedor.innerHTML = "<p>No tienes citas registradas</p>";
            return;
        }

        citas.forEach(cita => {
            let div = document.createElement("div");
            div.classList.add("cita");

            div.innerHTML = `
                <div class="cita-info">
                    <h3>${cita.mascota}</h3>
                    <p>📌 ${cita.servicio}</p>
                    <p>📅 ${cita.fecha}</p>
                </div>
                <button class="btn-delete" onclick="CitasService.eliminar(${cita.id})">X</button>
            `;

            contenedor.appendChild(div);
        });
    }
};

// ===== EVENTOS =====
document.addEventListener("DOMContentLoaded", () => {

    // LOGIN
    let btnLogin = document.getElementById("btnLogin");
    if (btnLogin) {
        btnLogin.addEventListener("click", () => {
            let correo = document.getElementById("loginCorreo").value;
            let pass = document.getElementById("loginPassword").value;

            Auth.login(correo, pass);
        });
    }

    // REGISTRO
    let btnRegistro = document.getElementById("btnRegistro");
    if (btnRegistro) {
        btnRegistro.addEventListener("click", () => {
            let correo = document.getElementById("registroCorreo").value;
            let pass = document.getElementById("registroPassword").value;

            Auth.registrar(correo, pass);
        });
    }

    // CITAS
    let btnCita = document.getElementById("btnCita");
    if (btnCita) {
        btnCita.addEventListener("click", () => {
            let mascota = document.getElementById("mascota").value;
            let servicio = document.getElementById("servicio").value;
            let fecha = document.getElementById("fecha").value;

            if (!mascota || !servicio || !fecha) {
                alert("Completa todos los campos");
                return;
            }

            CitasService.crear(mascota, servicio, fecha);
        });
    }

    // CARGAR CITAS AUTOMÁTICAMENTE
    UI.renderCitas();
});